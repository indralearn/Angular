import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-drinks-icon',
  templateUrl: './drinks-icon.component.html',
  styleUrls: ['./drinks-icon.component.css']
})
export class DrinksIconComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}