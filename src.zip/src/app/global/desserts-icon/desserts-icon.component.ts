import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-desserts-icon',
  templateUrl: './desserts-icon.component.html',
  styleUrls: ['./desserts-icon.component.css']
})
export class DessertsIconComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}