import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-starters-icon',
  templateUrl: './starters-icon.component.html',
  styleUrls: ['./starters-icon.component.css']
})
export class StartersIconComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}