import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-mains-icon',
  templateUrl: './mains-icon.component.html',
  styleUrls: ['./mains-icon.component.css']
})
export class MainsIconComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}