export const environment = {
  production: false,
  firebase: {
    projectId: 'restaurant-order-managem-684b3',
    appId: '1:966284662957:web:1f7e917a091602a49e0e24',
    storageBucket: 'restaurant-order-managem-684b3.appspot.com',
    apiKey: 'AIzaSyAqYu3r-ZRp1Ko2-52jvZ_TU4xuBGqPAYo',
    authDomain: 'restaurant-order-managem-684b3.firebaseapp.com',
    messagingSenderId: '966284662957',
  },
  UNSPLASH_SOURCE_API:
    'https://source.unsplash.com/1280x900/?restaurants,food,alcohol',
};